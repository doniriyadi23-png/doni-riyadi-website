export default function Home() {
  return (
    <main style={{fontFamily:'Arial, sans-serif', padding:'40px', lineHeight:'1.6'}}>
      <h1>Doni Riyadi Academy</h1>
      <p>Website pembelajaran Bahasa Jepang dan persiapan kerja ke Jepang.</p>
      <h2>Layanan</h2>
      <ul>
        <li>Kursus Bahasa Jepang</li>
        <li>Materi SSW Lengkap</li>
        <li>Pendampingan Rirekisho</li>
      </ul>
      <h2>Kontak</h2>
      <p>WhatsApp: +62 896-8203-7538</p>
      <p>Email: support@doniriyadi.com</p>
    </main>
  );
}
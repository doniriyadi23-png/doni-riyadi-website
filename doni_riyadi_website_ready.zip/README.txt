Upload folder ini ke Vercel untuk publish website.

Langkah:
1. Login ke vercel.com
2. Add New Project
3. Upload folder ini
4. Klik Deploy